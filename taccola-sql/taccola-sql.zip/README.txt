Taccola · The Missing Rain Bell

Extract the ZIP into one folder and open index.html directly in a modern
browser. Keep all of its files together. JavaScript and WebAssembly run
locally. There is no account, model connection, server or installation.

Choose Run query on the first clue. The starter finds one night room.
Remove LIMIT 1 and rerun to find all three. Choose Next clue and use the
registers and Rill’s hints to follow the bronze readings and packing seals.
View worked query supplies one real SQL solution for each chapter.

October 2023 historical source: Charles Lee’s taccola-qwik prototype.
Retained idea: a faithful companion guiding a three-level SQL narrative.
New work: Rill, the bell house mystery, synthetic records, quest writing,
interface, query evaluation, SQLite integration and companion artwork.
Bundled engine: sql.js 1.17.0 from Three Cheapest Crossings. See
sqlite-LICENSE.txt for the full upstream MIT notices.
