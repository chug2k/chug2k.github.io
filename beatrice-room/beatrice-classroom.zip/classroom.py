#!/usr/bin/env python3
"""Serve the Beatrice classroom kit on loopback or a trusted local network."""
import argparse
import hmac
import json
import re
import secrets
import socket
import sqlite3
import sys
import time
from contextlib import closing
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit

ROOT = Path(__file__).resolve().parent
STATIC = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/tokens.css": ("tokens.css", "text/css; charset=utf-8"),
    "/room.css": ("room.css", "text/css; charset=utf-8"),
    "/room.js": ("room.js", "text/javascript; charset=utf-8"),
    "/room-store.js": ("room-store.js", "text/javascript; charset=utf-8"),
    "/READ-ME.txt": ("READ-ME.txt", "text/plain; charset=utf-8"),
}
PUBLIC = ("id", "duration", "phase", "alias", "mood", "plan", "reflection", "deadline", "closedBy", "rev")
DURATIONS = (15, 60, 300)
CALL_SIGNS = ("Finch", "Kite", "Wren")
MOODS = ("Ready", "Unsure", "Need a minute")


class InputError(Exception):
    def __init__(self, message, status=400):
        super().__init__(message)
        self.status = status


def now_ms():
    return int(time.time() * 1000)


def text_field(value):
    if not isinstance(value, str) or not value.strip() or len(value.encode("utf-16-le")) // 2 > 1500:
        raise InputError("Use 1 to 1,500 characters for this entry.")
    return value.strip()


def fresh_room(duration):
    if type(duration) is not int or duration not in DURATIONS:
        raise InputError("Choose one of the planning windows.")
    return dict(id=secrets.token_hex(4).upper(), fac=secrets.token_hex(20), learner=secrets.token_hex(20),
                duration=duration, phase="lobby", alias="", mood="", plan="", reflection="",
                deadline=0, closedBy="", rev=0)


def expire(room, now):
    if room["phase"] == "planning" and now >= room["deadline"]:
        room.update(phase="reflection", closedBy="timer", rev=room["rev"] + 1)
        return True
    return False


def mutate(room, role, action, data, now):
    def gate(expected_role, *phases):
        if role != expected_role or room["phase"] not in phases:
            raise InputError("This action is unavailable in the current phase.", 409)

    value = data.get("value")
    if action == "join":
        gate("learner", "lobby")
        if value not in CALL_SIGNS:
            raise InputError("Choose a rehearsal call sign.")
        if room["alias"] and value != room["alias"]:
            raise InputError("This room already has a learner.", 409)
        room["alias"] = value
    elif action == "checkin":
        gate("facilitator", "lobby")
        if not room["alias"]:
            raise InputError("The learner must join first.", 409)
        room["phase"] = "checkin"
    elif action == "mood":
        gate("learner", "checkin")
        if value not in MOODS:
            raise InputError("Choose a check-in answer.")
        room.update(mood=value, phase="planning", deadline=now + room["duration"] * 1000)
    elif action == "plan":
        gate("learner", "planning", "reflection")
        room["plan"] = text_field(value)
    elif action == "reflect":
        gate("facilitator", "planning")
        room.update(phase="reflection", closedBy="facilitator")
    elif action == "finish":
        gate("learner", "reflection")
        room["reflection"] = text_field(value)
        if data.get("plan"):
            room["plan"] = text_field(data["plan"])
        room["phase"] = "complete"
    else:
        raise InputError("Unknown room action.")
    room["rev"] += 1


class Rooms:
    def __init__(self, path):
        self.path = path
        with closing(self.connect()) as db, db:
            db.execute("CREATE TABLE IF NOT EXISTS rooms (id TEXT PRIMARY KEY, state TEXT NOT NULL)")

    def connect(self):
        return sqlite3.connect(self.path, timeout=10)

    def create(self, duration):
        with closing(self.connect()) as db, db:
            while True:
                room = fresh_room(duration)
                row = db.execute("INSERT OR IGNORE INTO rooms VALUES (?, ?)", (room["id"], json.dumps(room)))
                if row.rowcount == 1:
                    return {"id": room["id"], "key": room["fac"], "role": "facilitator"}

    def access(self, code, token, payload):
        with closing(self.connect()) as db, db:
            db.execute("BEGIN IMMEDIATE")
            row = db.execute("SELECT state FROM rooms WHERE id = ?", (code,)).fetchone()
            room = json.loads(row[0]) if row else None
            role = None
            if room and re.fullmatch(r"[a-f0-9]{40}", token):
                if hmac.compare_digest(room["fac"], token):
                    role = "facilitator"
                elif hmac.compare_digest(room["learner"], token):
                    role = "learner"
            if not role:
                raise InputError("Room unavailable. Use the complete link supplied by the facilitator.", 404)
            now = now_ms()
            changed = expire(room, now)
            if payload is not None:
                mutate(room, role, payload.get("action"), payload, now)
                changed = True
            if changed:
                db.execute("UPDATE rooms SET state = ? WHERE id = ?", (json.dumps(room), code))
            view = {key: room[key] for key in PUBLIC}
            if role == "facilitator":
                view["learnerKey"] = room["learner"]
            return {"room": view, "role": role, "serverNow": now}


class Classroom(BaseHTTPRequestHandler):
    def reply(self, status, data, content_type):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(data)

    def json_reply(self, status, obj):
        self.reply(status, json.dumps(obj, ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")

    def payload(self):
        origin = self.headers.get("Origin")
        if origin and urlsplit(origin).netloc != self.headers.get("Host"):
            raise InputError("Open the room on the classroom host.", 403)
        if self.headers.get_content_type() != "application/json":
            raise InputError("Expected JSON.", 415)
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            size = 0
        if not 0 < size <= 32768:
            raise InputError("Room action is too large or missing.", 400)
        try:
            obj = json.loads(self.rfile.read(size).decode("utf-8"))
        except (ValueError, UnicodeError):
            raise InputError("The room action is unreadable.")
        if not isinstance(obj, dict):
            raise InputError("Expected a room action.")
        return obj

    def dispatch(self, post=False):
        path = urlsplit(self.path).path
        try:
            if not post and path in STATIC:
                name, mime = STATIC[path]
                data = (ROOT / name).read_bytes()
                if name == "index.html":
                    data = data.replace(b'data-mode="rehearsal"', b'data-mode="classroom"', 1)
                self.reply(200, data, mime)
                return
            if path == "/api/rooms" and post:
                self.json_reply(201, self.server.rooms.create(self.payload().get("duration")))
                return
            match = re.fullmatch(r"/api/rooms/([A-F0-9]{8})", path)
            if match:
                authorization = self.headers.get("Authorization", "")
                key = authorization[7:] if authorization.startswith("Bearer ") else ""
                self.json_reply(200, self.server.rooms.access(match[1], key, self.payload() if post else None))
                return
            raise InputError("Page unavailable.", 404)
        except InputError as problem:
            self.json_reply(problem.status, {"error": str(problem)})
        except (sqlite3.Error, OSError) as problem:
            if isinstance(problem, (BrokenPipeError, ConnectionResetError)):
                return
            self.json_reply(503, {"error": "The host could not read or save this room. Check its storage and retry."})

    def do_GET(self):
        self.dispatch()

    def do_POST(self):
        self.dispatch(True)

    def log_message(self, fmt, *args):
        pass  # The host prints startup addresses. Room activity stays in its local database.


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lan", action="store_true", help="listen on the local network for a second device")
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--data", type=Path, default=ROOT / "classroom-data.sqlite3", help="room database path")
    args = parser.parse_args()
    rooms = Rooms(args.data)
    with ThreadingHTTPServer(("0.0.0.0" if args.lan else "127.0.0.1", args.port), Classroom) as server:
        server.rooms = rooms
        port = server.server_port
        print("Beatrice Room is running on http://127.0.0.1:{}/".format(port), flush=True)
        if args.lan:
            try:
                addresses = {r[4][0] for r in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)}
            except OSError:
                addresses = set()
            for address in sorted(a for a in addresses if not a.startswith("127.")):
                print("Two-device address: http://{}:{}/".format(address, port), flush=True)
            print("Open http://<host-LAN-address>:{}/ on the facilitator device before copying the learner link.".format(port), flush=True)
        print("Room records: {}. Stop with Ctrl-C.".format(args.data), flush=True)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == "__main__":
    try:
        main()
    except (OSError, sqlite3.Error) as err:
        sys.exit("Could not start Beatrice Room: " + str(err))

