Layout Workbench

Extract the whole ZIP and open index.html in your browser.
Both the signal equipment and swatches are drawn with CSS.

Signal shelf: align the bottoms of the three pieces and distribute the unused
space between them. Edit the container declarations and choose Apply CSS.
Swatch drawer: set two equal grid columns and center each swatch in its cell.
Choose Hint and worked CSS for an example, then Load worked CSS and Apply CSS.

The geometry check measures positions and sizes at 240 and 440 CSS pixels.
The preview may scale down to fit a small screen. Measurements stay at the
specified layout widths. Each layout saves its draft locally when available.

The historical source is Minh’s CoderSchool Week 1 CSS layout challenge from
December 8, 2020. All shapes, target arrangements and exercise code here
were made for this public edition.
