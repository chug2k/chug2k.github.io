"""Rebuild Branch Room in a temporary Git repository. Requires Python 3 and Git 2.28+."""
import argparse
import json
import os
from pathlib import Path
import subprocess
import tempfile

FEATURE = "feature/last-entry"
SIGN = "desk/door-sign.txt"
PROGRAM = "program/workshops.txt"


def build_case():
    with tempfile.TemporaryDirectory(prefix="branch-room-") as tmp:
        root = Path(tmp)
        env = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
        env.update(GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL=os.devnull,
                   GIT_AUTHOR_NAME="Morrow Print Room", GIT_COMMITTER_NAME="Morrow Print Room",
                   GIT_AUTHOR_EMAIL="desk@example.invalid", GIT_COMMITTER_EMAIL="desk@example.invalid",
                   LC_ALL="C")

        def git(*args):
            return subprocess.run(["git", "-C", tmp, *args], env=env, check=True,
                                  capture_output=True, text=True).stdout.rstrip("\n")

        def commit(path, content, message, hour):
            file = root / path
            file.parent.mkdir(parents=True, exist_ok=True)
            file.write_text(content + "\n", encoding="utf-8")
            env["GIT_AUTHOR_DATE"] = env["GIT_COMMITTER_DATE"] = f"2000-01-01T{hour}:00:00+0000"
            git("add", "--", path)
            git("commit", "-qm", message)

        def tree(ref):
            return {p: git("show", f"{ref}:{p}") for p in git("ls-tree", "-r", "--name-only", ref).splitlines()}

        def compare(base):
            revisions = base + "..." + FEATURE
            files = git("diff", "--name-only", revisions).splitlines()
            commits = git("log", "--reverse", "--format=%h %s", base + ".." + FEATURE).splitlines()
            return {"commits": commits, "diffs": {p: git("diff", "--unified=2", revisions, "--", p)
                                                  for p in files}}

        git("init", "-q", "-b", "main", "--template=")
        (root / "program").mkdir()
        (root / PROGRAM).write_text("Saturday programme\n10:00  Open press\n", encoding="utf-8")
        git("add", PROGRAM)
        commit(SIGN, "Morrow Print Room\nLast entry 17:00\nDoors close 18:00", "Put the opening hours on the door", "10")
        git("checkout", "-qb", "develop")
        commit(PROGRAM, "Saturday programme\n10:00  Open press\n14:00  Indigo ink workshop",
               "Draft the indigo ink workshop", "11")
        git("checkout", "-qb", FEATURE)
        commit(SIGN, "Morrow Print Room\nLast entry 17:30\nDoors close 18:00",
               "Give visitors thirty more minutes", "12")
        refs = ["main", "develop", FEATURE]
        case = {
            "tips": {r: git("rev-parse", "--short=7", r) for r in refs},
            "trees": {r: tree(r) for r in refs},
            "comparisons": {base: compare(base) for base in ["main", "develop"]},
            "log": git("log", "--reverse", "--format=%h %s", FEATURE).splitlines()
        }
        git("checkout", "-q", "develop")
        git("merge", "--ff-only", FEATURE)
        case["merged"] = {
            "tip": git("rev-parse", "--short=7", "develop"), "develop": tree("develop"),
            "main": tree("main"), "review": compare("develop")
        }
        assert set(case["comparisons"]["main"]["diffs"]) == {SIGN, PROGRAM}
        assert set(case["comparisons"]["develop"]["diffs"]) == {SIGN}
        assert case["merged"]["main"] == case["trees"]["main"]
        assert case["merged"]["develop"] == case["trees"][FEATURE]
        assert case["merged"]["review"] == {"commits": [], "diffs": {}}
        return case


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--json", action="store_true", help="print the exact browser fixture")
    args = parser.parse_args()
    case = build_case()
    if args.json:
        print(json.dumps(case, ensure_ascii=False, indent=2))
    else:
        print("Morrow Print Room · local Git replay")
        for base, comparison in case["comparisons"].items():
            count = len(comparison["commits"])
            print(f"\nBase {base} · {count} commit" + ("" if count == 1 else "s"))
            for path, patch in comparison["diffs"].items():
                print(patch)
        print("\nAfter git merge --ff-only feature/last-entry into develop")
        for branch in ["main", "develop"]:
            print(branch, "·", case["merged"][branch][SIGN].splitlines()[1])
        print("Open review after merge · 0 files")
