Branch Room

Open index.html in a browser, with the other extracted files beside it.
The school guide behind this edition was introduced on June 17, 2021.
The Morrow Print Room case, repository, interface and writing are new.

Run review check on the default main base. Change Review base to develop
and run it again. Choose Merge into develop. The staging door sign now
admits visitors until 17:30. Production still reads 17:00.

Optional local replay (Git 2.28+ and Python 3.7+)
  python3 replay.py
  python3 replay.py --json

The replay initializes a temporary repository, commits both changes, compares
the branches and fast-forwards develop. It contacts no remote and discards
its own temporary directory when it finishes.
